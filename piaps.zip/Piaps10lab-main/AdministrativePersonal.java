import java.util.ArrayList;
import java.util.List;

class AdministrativePersonal extends Employee {
    private List<Faculty> managedFaculties; // Кафедры, которыми управляет

    public AdministrativePersonal(int ssn, String name, String email) {
        super(ssn, name, email);
        this.managedFaculties = new ArrayList<>();
    }

    // Метод: назначить декана на факультет
    public void assignDeanToFaculty(Faculty faculty, Dean dean) {
        if (faculty != null && dean != null) {
            faculty.assignDean(dean);
            System.out.println("Декан " + dean.getName() + " назначен на факультет " + faculty.getName());
        }
    }

    // Метод: добавить кафедру в факультет
    public void addInstituteToFaculty(Faculty faculty, Institute institute) {
        if (faculty != null && institute != null) {
            faculty.addDepartment(institute);
            System.out.println("Кафедра " + institute.getName() + " добавлена в факультет " + faculty.getName());
        }
    }

    // Метод: просмотреть всех сотрудников университета
    public void viewAllEmployees(University uni) {
        System.out.println("\n=== СПИСОК ВСЕХ СОТРУДНИКОВ ===");
        for (Faculty f : uni.getFaculties()) {
            System.out.println("Факультет: " + f.getName());
            for (Institute i : f.getInstitutes()) {
                System.out.println("  Кафедра: " + i.getName());
                for (ResearchStaff rs : i.getResearches()) {
                    System.out.println("    - " + rs.getName() + " (" + rs.getResearchArea() + ")");
                }
            }
        }
    }

    // Геттеры
    public List<Faculty> getManagedFaculties() { return managedFaculties; }

    @Override
    public String toString() {
        return "AdministrativePersonal{" +
                "ssn=" + getSsn() +
                ", name='" + getName() + '\'' +
                ", email='" + getEmail() + '\'' +
                '}';
    }
}