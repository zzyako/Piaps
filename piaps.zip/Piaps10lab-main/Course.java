import java.util.ArrayList;
import java.util.List;

class Course {
    private int id;
    private String name;
    private int weeklyDuration;
    private List<Lecturer> lecture;
    private CourseState state = CourseState.Draft;

    public Course(int id, String name, int weeklyDuration) {
        this.id = id;
        this.name = name;
        this.weeklyDuration = weeklyDuration;
        this.lecture = new ArrayList<>();

    }

    public enum CourseState {
        Draft, Scheduled, InProgress, Completed
    }
    public void schedule() {
        if (this.state == CourseState.Draft) {
            this.state = CourseState.Scheduled;
            System.out.println("Курс '" + name + "' добавлен в расписание.");
        }
    }

    public void startCourse() {
        if (this.state == CourseState.Scheduled) {
            this.state = CourseState.InProgress;
            System.out.println("Курс '" + name + "' начался.");
        }
    }

    public void finishCourse() {
        if (this.state == CourseState.InProgress) {
            this.state = CourseState.Completed;
            System.out.println("Курс '" + name + "' завершён.");
        }
    }

    public void addLecturer(Lecturer lect) {
        if (lect != null && !lecture.contains(lect)) {
            lecture.add(lect);
            lect.addCourse(this); // Обратная связь
        }
    }

    public void removeLecturer(Lecturer lect) {
        if (lect != null) {
            lecture.remove(lect);
        }
    }

    // Геттеры
    public int getId() { return id; }
    public String getName() { return name; }
    public int getWeeklyDuration() { return weeklyDuration; }
    public List<Lecturer> getLecturers() { return lecture; }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", weeklyDuration=" + weeklyDuration +
                '}';
    }
}