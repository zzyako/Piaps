class Dean extends Employee {
    public Dean(int ssn, String name, String email) {
        super(ssn, name, email);
    }

    public void approveProject(Project p) {
        System.out.println("Декан " + name + " утвердил проект: " + p.getName());
    }

    public void assignCourseToLecturer(Lecturer l, Course c) {
        l.addCourse(c);
        System.out.println("Декан " + name + " назначил курс " + c.getName() + " преподавателю " + l.getName());
    }
}