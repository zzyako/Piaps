class Employee {
    protected int ssn;
    protected String name;
    protected String email;

    public Employee(int ssn, String name, String email) {
        this.ssn = ssn;
        this.name = name;
        this.email = email;
    }

    public String getName() { return name; }
    public int getSsn() { return ssn; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return "Employee{" +
                "ssn=" + ssn +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}