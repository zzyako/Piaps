import java.util.ArrayList;
import java.util.List;

class Faculty {
    private String name;
    private Dean dean;
    private List<Institute> institutes;

    public Faculty(String name) {
        this.name = name;
        this.institutes = new ArrayList<>();
    }

    public void addDepartment(Institute d) {
        if (d != null && !institutes.contains(d)) {
            institutes.add(d);
        }
    }

    public void removeDepartment(Institute d) {
        if (d != null) {
            institutes.remove(d);
        }
    }

    public void assignDean(Dean d) {
        this.dean = d;
    }

    // Геттеры
    public String getName() { return name; }
    public Dean getDean() { return dean; }
    public List<Institute> getInstitutes() { return institutes; }

    @Override
    public String toString() {
        return "Faculty{" +
                "name='" + name + '\'' +
                ", dean=" + dean +
                '}';
    }
}