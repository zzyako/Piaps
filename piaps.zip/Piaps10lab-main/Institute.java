import java.util.ArrayList;
import java.util.List;

class Institute {
    private String name;
    private String address;
    private List<ResearchStaff> researches;

    public Institute(String name, String address) {
        this.name = name;
        this.address = address;
        this.researches = new ArrayList<>();
    }

    public void addResearchStaff(ResearchStaff e) {
        if (e != null && !researches.contains(e)) {
            researches.add(e);
            e.addInstitute(this); // Обратная связь
        }
    }

    public void removeResearchStaff(ResearchStaff e) {
        if (e != null) {
            researches.remove(e);
            e.removeInstitute(this); // Обратная связь
        }
    }

    // Геттеры
    public String getName() { return name; }
    public String getAddress() { return address; }
    public List<ResearchStaff> getResearches() { return researches; }

    @Override
    public String toString() {
        return "Institute{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}