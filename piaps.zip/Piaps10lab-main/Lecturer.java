import java.util.ArrayList;
import java.util.List;

class Lecturer extends ResearchStaff {
    private List<Course> courses;

    public Lecturer(int ssn, String name, String email, String researchArea) {
        super(ssn, name, email, researchArea);
        this.courses = new ArrayList<>();
    }

    public void addCourse(Course c) {
        if (c != null && !courses.contains(c)) {
            courses.add(c);
        }
    }

    // Геттеры
    public List<Course> getCourses() { return courses; }

    @Override
    public String toString() {
        return "Lecturer{" +
                "ssn=" + getSsn() +
                ", name='" + getName() + '\'' +
                ", researchArea='" + getResearchArea() + '\'' +
                ", courses=" + courses +
                '}';
    }
}