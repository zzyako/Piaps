import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Создаем университет
        University uni = new University();

        // Создаем факультет
        Faculty cs = new Faculty("Факультет Компьютерных Наук");
        uni.addFaculty(cs);

        // Создаем кафедру
        Institute ai = new Institute("Кафедра Искусственного Интеллекта", "ул. Университетская, 1");
        cs.addDepartment(ai);

        // Создаем декана
        Dean dean = new Dean(1, "Анна Иванова", "dean@uni.ru");
        cs.assignDean(dean);

        // Создаем научного сотрудника (преподавателя)
        Lecturer ivan = new Lecturer(2, "Иван Петров", "ivan@uni.ru", "Машинное обучение");

        // Прикрепляем к кафедре
        ai.addResearchStaff(ivan);

        // Создаем курс
        Course ml = new Course(101, "Введение в ML", 4);
        ivan.addCourse(ml);

        // Создаем административного персонала
        AdministrativePersonal admin = new AdministrativePersonal(3, "Мария Сидорова", "admin@uni.ru");

        // Администратор назначает декана
        admin.assignDeanToFaculty(cs, dean);

        // Администратор добавляет кафедру
        admin.addInstituteToFaculty(cs, ai);

        // Администратор просматривает всех сотрудников
        admin.viewAllEmployees(uni);



        // Создаем проект
        Project project = new Project("AI-2025", LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        Participation part = new Participation(ivan, 20);
        project.addParticipation(part);

        dean.approveProject(project);

        // Выводим информацию
        System.out.println("=== УНИВЕРСИТЕТ ===");
        System.out.println(uni);
        System.out.println("\n=== ФАКУЛЬТЕТ ===");
        System.out.println(cs);
        System.out.println("\n=== КАФЕДРА ===");
        System.out.println(ai);
        System.out.println("\n=== ПРЕПОДАВАТЕЛЬ ===");
        System.out.println(ivan);
        System.out.println("\n=== КУРС ===");
        System.out.println(ml);
        System.out.println("\n=== ПРОЕКТ ===");
        System.out.println(project);
    }
}