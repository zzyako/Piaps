class Participation {
    private int hours;
    private ResearchStaff research;

    public Participation(ResearchStaff research, int hours) {
        this.research = research;
        this.hours = hours;
    }

    // Геттеры
    public int getHours() { return hours; }
    public ResearchStaff getResearch() { return research; }

    @Override
    public String toString() {
        return "Participation{" +
                "hours=" + hours +
                ", research=" + research.getName() +
                '}';
    }
}