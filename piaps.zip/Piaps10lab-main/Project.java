import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class Project {
    private String name;
    private LocalDate startDate;
    private LocalDate endDate;
    private List<Participation> research;

    public Project(String name, LocalDate startDate, LocalDate endDate) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.research = new ArrayList<>();
    }

    public void addParticipation(Participation p) {
        if (p != null && !research.contains(p)) {
            research.add(p);
        }
    }

    // Геттеры
    public String getName() { return name; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public List<Participation> getResearch() { return research; }

    @Override
    public String toString() {
        return "Project{" +
                "name='" + name + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }
}