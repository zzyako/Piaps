import java.util.ArrayList;
import java.util.List;

class ResearchStaff extends Employee {
    private String researchArea;
    private List<Institute> institutes;
    private List<Project> projects; // Добавим список проектов

    public ResearchStaff(int ssn, String name, String email, String area) {
        super(ssn, name, email);
        this.researchArea = area;
        this.institutes = new ArrayList<>();
        this.projects = new ArrayList<>();
    }

    public void addInstitute(Institute i) {
        if (i != null && !institutes.contains(i)) {
            institutes.add(i);
        }
    }

    public void removeInstitute(Institute i) {
        if (i != null) {
            institutes.remove(i);
        }
    }

    // Геттеры
    public String getResearchArea() { return researchArea; }
    public List<Institute> getInstitutes() { return institutes; }
    public List<Project> getProjects() { return projects; }

    @Override
    public String toString() {
        return "ResearchStaff{" +
                "ssn=" + ssn +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", researchArea='" + researchArea + '\'' +
                ", institutes=" + institutes +
                '}';
    }
}