import java.util.ArrayList;
import java.util.List;

class University {
    private int numberOfEmployees;
    private List<Faculty> faculties;

    public University() {
        this.faculties = new ArrayList<>();
    }

    public void addFaculty(Faculty f) {
        if (f != null && !faculties.contains(f)) {
            faculties.add(f);
        }
    }

    public void removeFaculty(Faculty f) {
        if (f != null) {
            faculties.remove(f);
        }
    }

    public Faculty getFacultyByName(String name) {
        for (Faculty f : faculties) {
            if (f.getName().equals(name)) {
                return f;
            }
        }
        return null;
    }

    public int countEmployees() {
        int total = 0;
        for (Faculty f : faculties) {
            for (Institute i : f.getInstitutes()) {
                total += i.getResearches().size();
            }
        }
        return total;
    }

    // Геттеры
    public List<Faculty> getFaculties() { return faculties; }

    @Override
    public String toString() {
        return "University{" +
                "numberOfEmployees=" + countEmployees() +
                ", faculties=" + faculties +
                '}';
    }
}